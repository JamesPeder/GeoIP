# -*- coding: utf-8 -*-
#
# Licensed to the Apache Software Foundation (ASF) under one
# or more contributor license agreements.  See the NOTICE file
# distributed with this work for additional information
# regarding copyright ownership.  The ASF licenses this file
# to you under the Apache License, Version 2.0 (the
# "License"); you may not use this file except in compliance
# with the License.  You may obtain a copy of the License at
#
#   http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing,
# software distributed under the License is distributed on an
# "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
# KIND, either express or implied.  See the License for the
# specific language governing permissions and limitations
# under the License.

from __future__ import print_function, unicode_literals

import collections
import contextlib
import os
import random
import re
import subprocess
import time
import socket
from collections import OrderedDict
from tempfile import NamedTemporaryFile

import six
import unicodecsv as csv
from past.builtins import basestring
from past.builtins import unicode
from six.moves import zip

import airflow.security.utils as utils
from airflow.configuration import conf
from airflow.exceptions import AirflowException
from airflow.hooks.base_hook import BaseHook
from airflow.utils.file import TemporaryDirectory
from airflow.utils.helpers import as_flattened_list
from airflow.utils.operator_helpers import AIRFLOW_VAR_NAME_FORMAT_MAPPING


HIVE_QUEUE_PRIORITIES = ['VERY_HIGH', 'HIGH', 'NORMAL', 'LOW', 'VERY_LOW']




def get_context_from_env_var():
    """
    Extract context from env variable, e.g. dag_id, task_id and execution_date,
    so that they can be used inside BashOperator and PythonOperator.

    :return: The context of interest.
    """
    return {format_map['default']: os.environ.get(format_map['env_var_format'], '')
            for format_map in AIRFLOW_VAR_NAME_FORMAT_MAPPING.values()}



class HiveServer2Hook(BaseHook):
    """
    Wrapper around the pyhive library

    Notes:
    * the default authMechanism is PLAIN, to override it you
    can specify it in the ``extra`` of your connection in the UI
    * the default for run_set_variable_statements is true, if you
    are using impala you may need to set it to false in the
    ``extra`` of your connection in the UI
    """
    def __init__(self, hiveserver2_conn_id='hiveserver2_default'):
        self.hiveserver2_conn_id = hiveserver2_conn_id


    def get_conn(self, schema=None):
        """
        Returns a Hive connection object.
        """
        db = self.get_connection(self.hiveserver2_conn_id)
        auth_mechanism = db.extra_dejson.get('authMechanism', 'NONE')
        if auth_mechanism == 'NONE' and db.login is None:
            # we need to give a username
            username = 'airflow'
        kerberos_service_name = None
        if conf.get('core', 'security') == 'kerberos':
            auth_mechanism = db.extra_dejson.get('authMechanism', 'KERBEROS')
            kerberos_service_name = db.extra_dejson.get('kerberos_service_name', 'hive')

        # pyhive uses GSSAPI instead of KERBEROS as a auth_mechanism identifier
        if auth_mechanism == 'GSSAPI':
            self.log.warning(
                "Detected deprecated 'GSSAPI' for authMechanism "
                "for %s. Please use 'KERBEROS' instead",
                self.hiveserver2_conn_id
            )
            auth_mechanism = 'KERBEROS'

        from pyhive.hive import connect
        return connect(
            host=db.host,
            port=db.port,
            auth=auth_mechanism,
            kerberos_service_name=kerberos_service_name,
            username=db.login or username,
            password=db.password,
            database=schema or db.schema or 'default')



    def _get_results(self, hql, schema='default', fetch_size=None, hive_conf=None):
        from pyhive.exc import ProgrammingError
        if isinstance(hql, basestring):
            hql = [hql]
        previous_description = None
        with contextlib.closing(self.get_conn(schema)) as conn, \
                contextlib.closing(conn.cursor()) as cur:
            cur.arraysize = fetch_size or 1000

            # not all query services (e.g. impala AIRFLOW-4434) support the set command
            db = self.get_connection(self.hiveserver2_conn_id)
            if db.extra_dejson.get('run_set_variable_statements', True):
                env_context = get_context_from_env_var()
                if hive_conf:
                    env_context.update(hive_conf)
                for k, v in env_context.items():
                    cur.execute("set {}={}".format(k, v))

            for statement in hql:
                cur.execute(statement)
                # we only get results of statements that returns
                lowered_statement = statement.lower().strip()
                if (lowered_statement.startswith('select') or
                    lowered_statement.startswith('with') or
                    (lowered_statement.startswith('set') and
                     '=' not in lowered_statement)):
                    description = [c for c in cur.description]
                    if previous_description and previous_description != description:
                        message = '''The statements are producing different descriptions:
                                     Current: {}
                                     Previous: {}'''.format(repr(description),
                                                            repr(previous_description))
                        raise ValueError(message)
                    elif not previous_description:
                        previous_description = description
                        yield description
                    try:
                        # DB API 2 raises when no results are returned
                        # we're silencing here as some statements in the list
                        # may be `SET` or DDL
                        for row in cur:
                            yield row
                    except ProgrammingError:
                        self.log.debug("get_results returned no records")



    def get_results(self, hql, schema='default', fetch_size=None, hive_conf=None):
        """
        Get results of the provided hql in target schema.

        :param hql: hql to be executed.
        :type hql: str or list
        :param schema: target schema, default to 'default'.
        :type schema: str
        :param fetch_size: max size of result to fetch.
        :type fetch_size: int
        :param hive_conf: hive_conf to execute alone with the hql.
        :type hive_conf: dict
        :return: results of hql execution, dict with data (list of results) and header
        :rtype: dict
        """
        results_iter = self._get_results(hql, schema,
                                         fetch_size=fetch_size, hive_conf=hive_conf)
        header = next(results_iter)
        results = {
            'data': list(results_iter),
            'header': header
        }
        return results



    def to_csv(
            self,
            hql,
            csv_filepath,
            schema='default',
            delimiter=',',
            lineterminator='\r\n',
            output_header=True,
            fetch_size=1000,
            hive_conf=None):
        """
        Execute hql in target schema and write results to a csv file.

        :param hql: hql to be executed.
        :type hql: str or list
        :param csv_filepath: filepath of csv to write results into.
        :type csv_filepath: str
        :param schema: target schema, default to 'default'.
        :type schema: str
        :param delimiter: delimiter of the csv file, default to ','.
        :type delimiter: str
        :param lineterminator: lineterminator of the csv file.
        :type lineterminator: str
        :param output_header: header of the csv file, default to True.
        :type output_header: bool
        :param fetch_size: number of result rows to write into the csv file, default to 1000.
        :type fetch_size: int
        :param hive_conf: hive_conf to execute alone with the hql.
        :type hive_conf: dict

        """

        results_iter = self._get_results(hql, schema,
                                         fetch_size=fetch_size, hive_conf=hive_conf)
        header = next(results_iter)
        message = None

        i = 0
        with open(csv_filepath, 'wb') as f:
            writer = csv.writer(f,
                                delimiter=delimiter,
                                lineterminator=lineterminator,
                                encoding='utf-8')
            try:
                if output_header:
                    self.log.debug('Cursor description is %s', header)
                    writer.writerow([c[0] for c in header])

                for i, row in enumerate(results_iter, 1):
                    writer.writerow(row)
                    if i % fetch_size == 0:
                        self.log.info("Written %s rows so far.", i)
            except ValueError as exception:
                message = str(exception)

        if message:
            # need to clean up the file first
            os.remove(csv_filepath)
            raise ValueError(message)

        self.log.info("Done. Loaded a total of %s rows.", i)



    def get_records(self, hql, schema='default'):
        """
        Get a set of records from a Hive query.

        :param hql: hql to be executed.
        :type hql: str or list
        :param schema: target schema, default to 'default'.
        :type schema: str
        :param hive_conf: hive_conf to execute alone with the hql.
        :type hive_conf: dict
        :return: result of hive execution
        :rtype: list

        >>> hh = HiveServer2Hook()
        >>> sql = "SELECT * FROM airflow.static_babynames LIMIT 100"
        >>> len(hh.get_records(sql))
        100
        """
        return self.get_results(hql, schema=schema)['data']



    def get_pandas_df(self, hql, schema='default', **kwargs):
        """
        Get a pandas dataframe from a Hive query

        :param hql: hql to be executed.
        :type hql: str or list
        :param schema: target schema, default to 'default'.
        :type schema: str
        :param kwargs: (optional) passed into pandas.DataFrame constructor
        :type kwargs: dict
        :return: result of hql execution
        :rtype: DataFrame

        >>> hh = HiveServer2Hook()
        >>> sql = "SELECT * FROM airflow.static_babynames LIMIT 100"
        >>> df = hh.get_pandas_df(sql)
        >>> len(df.index)
        100

        :return: pandas.DateFrame
        """
        import pandas as pd
        res = self.get_results(hql, schema=schema)
        df = pd.DataFrame(res['data'], **kwargs)
        df.columns = [c[0] for c in res['header']]
        return df
