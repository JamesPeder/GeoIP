
CREATE DATABASE IF NOT EXISTS airflow;

CREATE TABLE IF NOT EXISTS airflow.locations(
	geoname_id VARCHAR(255),
	country_name VARCHAR(255),
	region VARCHAR(255),
	city_name VARCHAR(255),
	PRIMARY KEY(geoname_id)
);

CREATE TABLE IF NOT EXISTS airflow.ipv4(
	network VARCHAR(255),
	geoname_id VARCHAR(255),
	PRIMARY KEY(network),
	FOREIGN KEY(geoname_id) REFERENCES airflow.locations(geoname_id)
);


CREATE TABLE IF NOT EXISTS airflow.ipv6(
	network VARCHAR(255), 
	geoname_id VARCHAR(255),
	PRIMARY KEY(network),
	FOREIGN KEY (geoname_id) REFERENCES airflow.locations(geoname_id)
);
