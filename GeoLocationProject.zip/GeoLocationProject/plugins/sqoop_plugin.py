from airflow.plugins_manager import AirflowPlugin
from operators.sqoop_operator import *
from hooks.sqoop_hook import *

# Defining the plugin class
class SqoopPlugin(AirflowPlugin):
    name = "sqoop_plugin"
    operators = [SqoopOperator]
    flask_blueprints = []
    hooks = [SqoopHook]
    executors = []
    admin_views = []
    menu_links = []