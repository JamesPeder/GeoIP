from airflow.plugins_manager import AirflowPlugin
from airflow.models import BaseOperator
from airflow.utils.decorators import apply_defaults
from airflow.exceptions import AirflowException

from pathlib import Path
import re
import os


class RenameUnknownDirectoryOperator(BaseOperator):
    template_fields = ('parent_directory', 'directory_pattern', 'new_name')
    ui_color = '#427bf5'

    @apply_defaults
    def __init__(
            self,
            parent_directory,
            directory_pattern,
            new_name,
            *args, **kwargs):
        """
        :param parent_directory: destination directory
        :type parent_directory: string
        :param pattern: parent
        :type: pattern: string
        """

        super(RenameUnknownDirectoryOperator, self).__init__(*args, **kwargs)
        self.parent_directory = parent_directory
        self.directory_pattern = directory_pattern
        self.new_name = new_name

    def execute(self, context):
        self.log.info("RemoveRootDirectoryOperator execution started.")

        # Get files in folder
        objs = os.listdir(self.parent_directory)

        # Go through files and get the first that matches the pattern
        matches = list(filter(lambda name: re.match(self.directory_pattern, name) and os.path.isdir(f"{self.parent_directory}/{name}"), objs))

        if len(matches) == 0:
            raise AirflowException("Error, no directories match")

        filename = matches[0]
        source = f"{self.parent_directory}/{filename}"

        # Remove the folder and put contents in path directory
        destination = f"{self.parent_directory}/{self.new_name}"

        self.log.info("removing root directory '" + self.parent_directory + "'")

        os.rename(source, destination)

        self.log.info("RemoveRootDirectoryOperator done.")

