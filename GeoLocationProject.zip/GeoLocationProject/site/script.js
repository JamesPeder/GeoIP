function search() {
  let ip_elem = document.getElementById("ip_input");
  let ip = ip_elem.value;

  console.log("searching for" + ip);

  get_location(ip);
}

function get_location(ip) {
  function set_address(address) {
    console.log(address);
    document.getElementById("country").innerText = address["country_name"];
    document.getElementById("region").innerText = address["region"];
    document.getElementById("city").innerText = address["city_name"];
  }

  let isipv4 = true;

  let hostip = document.getElementById("server_ip_input").value;

  response = "";

  if (!ip.includes(":")) {
    fetch("http://" + hostip + ":8085/v4/getlocation/?ip=" + ip, {
      method: "GET",
      headers: {
        Accept: "application/json",
      },
    })
      .then((response) => response.json())
      .then((data) => set_address(data));
  } else {
    fetch("http://" + hostip + ":8085/v6/getlocation/?ip=" + ip, {
      method: "GET",
      headers: {
        Accept: "application/json",
      },
    })
      .then((response) => response.json())
      .then((data) => set_address(data));
  }
}

function get_current_ip() {
  function set_current_ip(ip) {
    document.getElementById("current-ip").innerText = ip;
    get_location(ip);
  }

  let hostip = document.getElementById("server_ip_input").value;

  fetch("http://" + hostip + ":8085/getip", {
    method: "GET",
    headers: {
      Accept: "application/json",
    },
  })
    .then((response) => response.json())
    .then((data) => set_current_ip(data["ip"]));
}

function init() {
  // initialisation
  document.getElementById("server_ip_input").value = "localhost";
  get_current_ip();
}

init();
