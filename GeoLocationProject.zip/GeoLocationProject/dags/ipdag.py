from datetime import datetime
from airflow import DAG
from airflow.operators.dummy_operator import DummyOperator
from airflow.contrib.operators.spark_submit_operator import SparkSubmitOperator
from airflow.operators.http_download_operations import HttpDownloadOperator

from airflow.operators.zip_file_operations import UnzipFileOperator
from airflow.operators.zip_operator_plugin import UnzipOperator

from airflow.operators.hdfs_operations import HdfsPutFileOperator, HdfsGetFileOperator, HdfsMkdirFileOperator
from airflow.operators.filesystem_operations import CreateDirectoryOperator
from airflow.operators.filesystem_operations import ClearDirectoryOperator
from airflow.operators.custom_system_operators import RenameUnknownDirectoryOperator
from airflow.operators.hive_operator import HiveOperator
from airflow.operators.hive_to_mysql import HiveToMySqlOperator
from airflow.providers.mysql.operators.mysql import MySqlOperator
from airflow.operators.sqoop_plugin import SqoopOperator

personal_data_token = "3AQXvvS84LYoZDUj"
data_download_link = f"https://download.maxmind.com/app/geoip_download?edition_id=GeoLite2-City-CSV&license_key={personal_data_token}&suffix=zip"

args = {
'owner': 'airflow'
}
dag = DAG('DataImport', default_args=args, description='dag', schedule_interval='56 18 * * *', start_date=datetime(2019, 10, 16), catchup=False, max_active_runs=1)

# Create directories (if not exists)
create_local_geo_ip_directory = CreateDirectoryOperator(
    task_id='create_geo_ip_dir',
    path='/home/airflow',
    directory='geo_ip',
    dag=dag

)

create_local_geo_ip_raw_directory = CreateDirectoryOperator(
    task_id='create_raw_dir',
    path='/home/airflow/geo_ip',
    directory='raw',
    dag=dag

)

# Clear raw data directory

clear_raw_dir = ClearDirectoryOperator(
    task_id='clear_import_dir',
    directory='/home/airflow/geo_ip/raw',
    pattern='**/*',
    dag=dag,
)

# Download

download_raw_data = HttpDownloadOperator(
    task_id='download_raw_data',
    download_uri=data_download_link,
    save_to='/home/airflow/geo_ip/raw/zip.zip',
    dag=dag,
)

# Unzip to raw
unzip_raw = UnzipOperator(
    task_id='unzip_raw',
    path_to_zip_file='/home/airflow/geo_ip/raw/zip.zip',
    path_to_unzip_contents='/home/airflow/geo_ip/raw/',
    dag=dag
)

# Remove root folder to access the contents
remove_unzipped_root_directory = RenameUnknownDirectoryOperator(
    task_id='rename_folder_to_unzipped',
    parent_directory='/home/airflow/geo_ip/raw',
    directory_pattern="GeoLite2-City-CSV*",
    new_name="unzipped",
    dag=dag
)


# HDFS:

# Create hdfs raw directory

create_hdfs_raw_directory_ipv4 = HdfsMkdirFileOperator(
    task_id='mkdir_hdfs_raw_ipv4',
    directory='/user/hadoop/geo_ip/raw/ipv4/',
    hdfs_conn_id='hdfs',
    dag=dag,
)

create_hdfs_raw_directory_ipv6 = HdfsMkdirFileOperator(
    task_id='mkdir_hdfs_raw_ipv6',
    directory='/user/hadoop/geo_ip/raw/ipv6/',
    hdfs_conn_id='hdfs',
    dag=dag,
)

create_hdfs_raw_directory_locations = HdfsMkdirFileOperator(
    task_id='mkdir_hdfs_raw_locations',
    directory='/user/hadoop/geo_ip/raw/locations/',
    hdfs_conn_id='hdfs',
    dag=dag,
)

# Create hdfs final directory

create_hdfs_final_directory_ipv4 = HdfsMkdirFileOperator(
    task_id='mkdir_hdfs_final_ipv4',
    directory='/user/hadoop/geo_ip/final/ipv4/',
    hdfs_conn_id='hdfs',
    dag=dag,
)

create_hdfs_final_directory_ipv6 = HdfsMkdirFileOperator(
    task_id='mkdir_hdfs_final_ipv6',
    directory='/user/hadoop/geo_ip/final/ipv6/',
    hdfs_conn_id='hdfs',
    dag=dag,
)

create_hdfs_final_directory_locations = HdfsMkdirFileOperator(
    task_id='mkdir_hdfs_final_locations',
    directory='/user/hadoop/geo_ip/final/locations/',
    hdfs_conn_id='hdfs',
    dag=dag,
)

# Move to hdfs

# move ipv4
hdfs_put_ipv4 = HdfsPutFileOperator(
    task_id='upload_ipv4_to_hdfs',
    local_file=f'/home/airflow/geo_ip/raw/unzipped/GeoLite2-City-Blocks-IPv4.csv',
    remote_file='/user/hadoop/geo_ip/raw/ipv4/IPv4.csv',
    hdfs_conn_id='hdfs',
    dag=dag,
)

# move ipv6
hdfs_put_ipv6 = HdfsPutFileOperator(
    task_id='upload_ipv6_to_hdfs',
    local_file=f'/home/airflow/geo_ip/raw/unzipped/GeoLite2-City-Blocks-IPv6.csv',
    remote_file='/user/hadoop/geo_ip/raw/ipv6/IPv6.csv',
    hdfs_conn_id='hdfs',
    dag=dag,
)

# move en
hdfs_put_en = HdfsPutFileOperator(
    task_id='upload_en_to_hdfs',
    local_file=f'/home/airflow/geo_ip/raw/unzipped/GeoLite2-City-Locations-en.csv',
    remote_file='/user/hadoop/geo_ip/raw/locations/en.csv',
    hdfs_conn_id='hdfs',
    dag=dag,
)

# Hive:

# Create ipv4 table

hiveSQL_drop_tables = '''
DROP TABLE IF EXISTS rawipv4;
DROP TABLE IF EXISTS rawipv6;
DROP TABLE IF EXISTS ipv4;
DROP TABLE IF EXISTS ipv6;
DROP TABLE IF EXISTS rawlocations;
DROP TABLE IF EXISTS locations;
'''

drop_HiveTables = HiveOperator(
    task_id='drop_tables',
    hql=hiveSQL_drop_tables,
    hive_cli_conn_id='beeline',
    dag=dag)

hiveSQL_ipv4_raw_table = '''
CREATE EXTERNAL TABLE IF NOT EXISTS rawipv4(
	network STRING,
    geoname_id STRING,
    registered_country_geoname_id STRING,
    represented_country_geoname_id STRING,
    is_anonymous_proxy STRING,
    is_satellite_provider STRING,
    postal_code STRING,
    latitude STRING,
    longitude STRING,
    accuracy_radius STRING
) COMMENT 'ipv4' ROW FORMAT DELIMITED FIELDS TERMINATED BY ',' STORED AS TEXTFILE LOCATION '/user/hadoop/geo_ip/raw/ipv4/'
TBLPROPERTIES ('skip.header.line.count'='1');
'''

create_HiveTable_raw_ipv4 = HiveOperator(
    task_id='create_ipv4_raw_table',
    hql=hiveSQL_ipv4_raw_table,
    hive_cli_conn_id='beeline',
    dag=dag)

# Create ipv6 table

hiveSQL_ipv6_raw_table = '''
CREATE EXTERNAL TABLE IF NOT EXISTS rawipv6(
	network STRING,
    geoname_id STRING,
    registered_country_geoname_id STRING,
    represented_country_geoname_id STRING,
    is_anonymous_proxy STRING,
    is_satellite_provider STRING,
    postal_code STRING,
    latitude STRING,
    longitude STRING,
    accuracy_radius STRING
) COMMENT 'ipv6' ROW FORMAT DELIMITED FIELDS TERMINATED BY ',' STORED AS TEXTFILE LOCATION '/user/hadoop/geo_ip/raw/ipv6/'
TBLPROPERTIES ('skip.header.line.count'='1');
'''

create_HiveTable_raw_ipv6 = HiveOperator(
    task_id='create_ipv6_raw_table',
    hql=hiveSQL_ipv6_raw_table,
    hive_cli_conn_id='beeline',
    dag=dag)

# locations raw table

hiveSQL_locations_raw_table = '''
CREATE EXTERNAL TABLE IF NOT EXISTS rawlocations(
    geoname_id STRING,
    locale_code STRING,
    continent_code STRING,
    continent_name STRING,
    country_iso_code STRING,
    country_name STRING,
    subdivision_1_iso_code STRING,
    subdivision_1_name STRING,
    subdivision_2_iso_code STRING,
    subdivision_2_name STRING,
    city_name STRING,
    metro_code STRING,
    time_zone STRING,
    is_in_european_union STRING
) COMMENT 'locations' ROW FORMAT DELIMITED FIELDS TERMINATED BY ',' STORED AS TEXTFILE LOCATION '/user/hadoop/geo_ip/raw/locations/'
TBLPROPERTIES ('skip.header.line.count'='1');
'''

create_HiveTable_raw_locations = HiveOperator(
    task_id='create_locations_raw_table',
    hql=hiveSQL_locations_raw_table,
    hive_cli_conn_id='beeline',
    dag=dag)


# Mapping to final tables

hiveSQL_ipv4_final_table = '''
CREATE TABLE ipv4 STORED AS TEXTFILE LOCATION '/user/hadoop/geo_ip/final/ipv4' AS SELECT  network, geoname_id FROM rawipv4 WHERE geoname_id IN (SELECT geoname_id FROM locations)
'''


create_HiveTable_final_ipv4 = HiveOperator(
    task_id='create_ipv4_final_table',
    hql=hiveSQL_ipv4_final_table,
    hive_cli_conn_id='beeline',
    dag=dag)

# Create ipv6 table

hiveSQL_ipv6_final_table = '''
CREATE TABLE ipv6 STORED AS TEXTFILE LOCATION '/user/hadoop/geo_ip/final/ipv6' AS SELECT  network, geoname_id FROM rawipv6 WHERE geoname_id IN (SELECT geoname_id FROM locations)
'''

create_HiveTable_final_ipv6 = HiveOperator(
    task_id='create_ipv6_final_table',
    hql=hiveSQL_ipv6_final_table,
    hive_cli_conn_id='beeline',
    dag=dag)

# Create locations table
hiveSQL_locations_final_table = '''
CREATE TABLE locations STORED AS TEXTFILE LOCATION '/user/hadoop/geo_ip/final/locations' AS SELECT geoname_id, country_name, subdivision_1_name AS region, city_name FROM rawlocations
'''

create_HiveTable_final_locations = HiveOperator(
    task_id='create_locations_final_table',
    hql=hiveSQL_locations_final_table,
    hive_cli_conn_id='beeline',
    dag=dag)

# Drops empty tables
clear_mysql_tables = MySqlOperator(
    task_id="clear_mysql_tables",
    sql="DELETE FROM airflow.ipv4;DELETE FROM airflow.ipv6;DELETE FROM airflow.locations;",
    database="airflow"
)

# Move data to tables
ipv4_to_mysql = HiveToMySqlOperator(
    task_id="ipv4_to_myql",
    sql="SELECT * FROM ipv4",
    mysql_table="ipv4",
    hiveserver2_conn_id="beeline",
    mysql_conn_id=None,
    dag=dag
)

ipv6_to_mysql = HiveToMySqlOperator(
    task_id="ipv6_to_myql",
    sql="SELECT * FROM ipv6",
    mysql_table="ipv6",
    hiveserver2_conn_id="beeline",
    mysql_conn_id=None,
    dag=dag
)

locations_to_mysql = HiveToMySqlOperator(
    task_id="locations_to_myql",
    sql="SELECT * FROM locations",
    mysql_table="locations",
    hiveserver2_conn_id="beeline",
    mysql_conn_id=None,
    dag=dag
)

# Process dependencies:

# Get zips ready for transport to hive
create_local_geo_ip_directory >> create_local_geo_ip_raw_directory >> clear_raw_dir >> download_raw_data >> unzip_raw >> remove_unzipped_root_directory

# Drop hive tables if not exists
drop_HiveTables >> create_hdfs_raw_directory_ipv4
drop_HiveTables >> create_hdfs_raw_directory_ipv6
drop_HiveTables >> create_hdfs_raw_directory_locations
drop_HiveTables >> create_hdfs_final_directory_ipv4
drop_HiveTables >> create_hdfs_final_directory_ipv6
drop_HiveTables >> create_hdfs_final_directory_locations

# Map ipv4 to final hive table
create_hdfs_raw_directory_ipv4 >> hdfs_put_ipv4
remove_unzipped_root_directory >> hdfs_put_ipv4 >> create_HiveTable_raw_ipv4 >> create_HiveTable_final_ipv4
create_hdfs_final_directory_ipv4 >> create_HiveTable_final_ipv4 >> ipv4_to_mysql
create_HiveTable_final_locations >> create_HiveTable_final_ipv4

# Map ipv6 to final hive table
create_hdfs_raw_directory_ipv6 >> hdfs_put_ipv6
remove_unzipped_root_directory >> hdfs_put_ipv6 >> create_HiveTable_raw_ipv6 >> create_HiveTable_final_ipv6
create_hdfs_final_directory_ipv6 >> create_HiveTable_final_ipv6 >> ipv6_to_mysql
create_HiveTable_final_locations >> create_HiveTable_final_ipv6

# Locations to final hive table
create_hdfs_raw_directory_locations >> hdfs_put_en
remove_unzipped_root_directory >> hdfs_put_en >> create_HiveTable_raw_locations >> create_HiveTable_final_locations
create_hdfs_final_directory_locations >> create_HiveTable_final_locations >> locations_to_mysql

locations_to_mysql >> ipv4_to_mysql
locations_to_mysql >> ipv6_to_mysql

clear_mysql_tables >> ipv4_to_mysql
clear_mysql_tables >> ipv6_to_mysql
clear_mysql_tables >> locations_to_mysql

