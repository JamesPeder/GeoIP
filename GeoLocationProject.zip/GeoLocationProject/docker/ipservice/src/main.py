from flask import Flask, request, jsonify, render_template
from flask_cors import CORS
import MySQLdb
import ipaddress


PORT = 8085
HOST = "localhost"
# HOST = "mysql"
MYSQL_CONF = {
    "user": 'root', 
    "password": '',
    "host": HOST,
    "database": 'airflow'
}

app = Flask(__name__)
cors = CORS(app, resources={r"/*": {"origins": "*"}})


@app.route("/")
def ping():
    return "<p>Service works!</p>"

@app.route("/getip", methods=["GET"])
def get_my_ip():
    return jsonify({'ip': request.remote_addr}), 200


@app.route('/v4/getlocation/', methods=["get"])
def get_location_v4():
    ip = request.args.get('ip')
    if "/" in ip:
        ip = ip.split("/")[0]
    return get_address_by_ipv4(ip)


@app.route('/v6/getlocation/', methods=["get"])
def get_location_v6(ip):
    ip = request.args.get('ip')
    return get_address_by_ipv6(ip)



def execute_query(sql, args=[], fetchone=False):

    db = MySQLdb.connect(**MYSQL_CONF)
    cursor = db.cursor()
    cursor.execute(sql, args)
    results = None
    if fetchone:
        results = cursor.fetchone()
    else:
        results = cursor.fetchall()
    db.close()

    return results

def get_address_by_ipv4(ip):
    
    sub_nets = execute_query("SELECT ip.network FROM airflow.ipv4 AS ip WHERE ip.network LIKE CONCAT(%s, '%%')", (".".join(ip.split(".")[:-2]),))

    correct_subnet = sub_nets[0]

    for subnet in sub_nets:
        try:
            if ipaddress.ip_address(ip) in ipaddress.ip_network(subnet[0]):
                correct_subnet = subnet[0]
                break
        except:
            pass
    
    result = execute_query("SELECT loc.country_name, loc.region, loc.city_name FROM airflow.locations AS loc, airflow.ipv4 AS ip WHERE ip.geoname_id = loc.geoname_id AND ip.network = %s", (correct_subnet,), fetchone=True)
    
    return jsonify({
        "country_name": result[0].replace("\"", ""),
        "region": result[1],
        "city_name": result[2]
    })

def get_address_by_ipv6(ip):
    sub_nets = execute_query("SELECT network FROM airflow.ipv6 AS ip WHERE ip.network LIKE CONCAT(%s, '%%')", (".".join(ip.split(":")[:-1]),))

    correct_subnet = sub_nets[0]

    for subnet in sub_nets:
        try:
            if ipaddress.ip_address(ip) in ipaddress.ip_network(subnet[0]):
                correct_subnet = subnet[0]
                break
        except:
            pass
    
    result = execute_query("SELECT loc.country_name, loc.region, loc.city_name FROM airflow.locations AS loc, airflow.ipv6 AS ip WHERE ip.geoname_id = loc.geoname_id AND ip.network = %s", (correct_subnet,), fetchone=True)
    
    return jsonify({
        "country_name": result[0].replace("\"", ""),
        "region": result[1],
        "city_name": result[2]
    })


if __name__ == '__main__':
    app.run(host="0.0.0.0", port=PORT)

