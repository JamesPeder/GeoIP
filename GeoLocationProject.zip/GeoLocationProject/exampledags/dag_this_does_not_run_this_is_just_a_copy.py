from datetime import datetime
from airflow import DAG
from airflow.operators.dummy_operator import DummyOperator
from airflow.contrib.operators.spark_submit_operator import SparkSubmitOperator
from airflow.operators.http_download_operations import HttpDownloadOperator
from airflow.operators.zip_file_operations import UnzipFileOperator
from airflow.operators.hdfs_operations import HdfsPutFileOperator, HdfsGetFileOperator, HdfsMkdirFileOperator
from airflow.operators.filesystem_operations import CreateDirectoryOperator
from airflow.operators.filesystem_operations import ClearDirectoryOperator
from airflow.operators.hive_operator import HiveOperator

data_download_link = "https://download.maxmind.com/app/geoip_download?edition_id=GeoLite2-City-CSV&license_key=3AQXvvS84LYoZDUj&suffix=tar.gz"

args = {
'owner': 'airflow'
}
dag = DAG('DataImport', default_args=args, description='dag', schedule_interval='56 18 * * *', start_date=datetime(2019, 10, 16), catchup=False, max_active_runs=1)

# HIVE DDL:

hiveSQL_ipv4_table = '''
CREATE EXTERNAL TABLE IF NOT EXISTS ipv4(
	network STRING,
    geoname_id INT,
    registered_country_geoname_id INT,
    represented_country_geoname_id INT,
    is_anonymous_proxy INT,
    is_satellite_provider INT
) COMMENT 'ipv4' PARTITIONED BY (network STRING, geoname_id INT, registered_country_geoname_id INT, represented_country_geoname_id INT, is_anonymous_proxy INT, is_satellite_provider INT) ROW FORMAT DELIMITED FIELDS TERMINATED BY '\\t' STORED AS TEXTFILE LOCATION '/user/hadoop/geo_ip/raw/unzipped/'
TBLPROPERTIES ('skip.header.line.count'='1');
'''

hiveSQL_ipv6_table = '''
CREATE EXTERNAL TABLE IF NOT EXISTS ipv6(
	network STRING,
    geoname_id INT,
    registered_country_geoname_id INT,
    represented_country_geoname_id INT,
    is_anonymous_proxy INT,
    is_satellite_provider INT
) COMMENT 'ipv6' PARTITIONED BY (partition_year int, partition_month int, partition_day int) ROW FORMAT DELIMITED FIELDS TERMINATED BY '\\t' STORED AS TEXTFILE LOCATION '/user/hadoop/geo_ip/raw'
TBLPROPERTIES ('skip.header.line.count'='1');
'''

# Create directories (if not exists)

create_local_geo_ip_directory = CreateDirectoryOperator(
    task_id='create_geo_ip_dir',
    path='/home/airflow',
    directory='geo_ip',
    dag=dag

)

create_local_geo_ip_raw_directory = CreateDirectoryOperator(
    task_id='create_raw_dir',
    path='/home/airflow/geo_ip',
    directory='raw',
    dag=dag

)

# Clear raw data directory

clear_raw_dir = ClearDirectoryOperator(
    task_id='clear_import_dir',
    directory='/home/airflow/geo_ip/raw',
    pattern='*',
    dag=dag,
)

# Download

download_raw_data = HttpDownloadOperator(
    task_id='download_raw_data',
    download_uri=data_download_link,
    save_to='/home/airflow/geo_ip/raw/zip.tar.gz',
    dag=dag,
)

# Unzip to raw
# BashOperator(
#     task_id='unzip_title_ratings',
#     bash_command='unzip -O /home/airflow/geo_ip/raw/unzipped /home/airflow/geo_ip/raw/zip.zip'
# )

unzip_title_ratings = UnzipFileOperator(
    task_id='unzip_title_ratings',
    zip_file='/home/airflow/geo_ip/raw/zip.tar.gz',
    extract_to='/home/airflow/geo_ip/raw/unzipped.tar',
    dag=dag,
)

# HDFS:

# Create hdfs raw directory

create_hdfs_directories = HdfsMkdirFileOperator(
    task_id='mkdir_hdfs_raw',
    directory='/user/hadoop/geo_ip/raw/{{ macros.ds_format(ds, "%Y-%m-%d", "%Y")}}/{{ macros.ds_format(ds, "%Y-%m-%d", "%m")}}/{{ macros.ds_format(ds, "%Y-%m-%d", "%d")}}',
    hdfs_conn_id='hdfs',
    dag=dag,
)

# Hive:

# Create ipv4 table

# Create ipv6 table

# Create de table

# Create en table

# Create es table

# Create fr table

# Create ja table

# Create br table

# Create ru table

# Create zh table

# create_HiveTable_title_ratings = HiveOperator(
#     task_id='create_title_ratings_table',
#     hql=hiveSQL_create_table_title_ratings,
#     hive_cli_conn_id='beeline',
#     dag=dag)

# Move to db

# Done :D


# task_1 = BashOperator(task_id='removeolddata', bash_command='rm user/hadoop/geo_ip/raw/latest-zip.zip', dag=dag)
# task_2 = BashOperator(task_id='getdata', bash_command='wget -O user/hadoop/geo_ip/raw/latest-zip.zip https://download.maxmind.com/app/geoip_download_by_token?edition_id=GeoLite2-City-CSV&date=20221118&suffix=zip&token=v2.local.39jMY9a6HcC7I91PycyJR_I71Jwx-gXBESdC1wV2kAzTw9N60E4egex5_Ef-bVmjJ8dQu2kceliy1cL_dR-3hhqLoCR8uhWrCXJ_1NpTD_3m5wivov1N4cECemVYgHjqCjk-8-u6s9O2iRw_Y0d2hWqctgg0Erpi7Tr2F-zCf8nt_qtPXwg4e9I0UcigzpNzDT2xug', dag=dag)
# task_3 = BashOperator(task_id='unzipdata', bash_command='unzip user/hadoop/geo_ip/raw/latest-zip.zip -d unzip user/hadoop/geo_ip/raw/', retries=3, dag=dag)



create_local_geo_ip_directory >> create_local_geo_ip_raw_directory >> clear_raw_dir >> download_raw_data >> unzip_title_ratings
unzip_title_ratings >> create_hdfs_directories
