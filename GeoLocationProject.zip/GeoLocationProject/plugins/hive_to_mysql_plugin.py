from airflow.plugins_manager import AirflowPlugin
from operators.hive_to_mysql_operator import *

# Defining the plugin class
class ZipOperatorPlugin(AirflowPlugin):
    name = "hive_to_mysql"
    operators = [HiveToMySqlOperator]
    flask_blueprints = []
    hooks = []
    executors = []
    admin_views = []
    menu_links = []