from airflow.plugins_manager import AirflowPlugin
from operators.RenameUnknownDirectoryOperator import *

class CustomSystemOperators(AirflowPlugin):
    name = "custom_system_operators"
    operators = [RenameUnknownDirectoryOperator]
    hooks = []
    executors = []
    macros = []
    admin_views = []
    flask_blueprints = []
    menu_links = []
