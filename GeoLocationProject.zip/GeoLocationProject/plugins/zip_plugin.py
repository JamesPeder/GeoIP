from airflow.plugins_manager import AirflowPlugin
from operators.zip_operator import *

# Defining the plugin class
class ZipOperatorPlugin(AirflowPlugin):
    name = "zip_operator_plugin"
    operators = [ZipOperator, UnzipOperator]
    flask_blueprints = []
    hooks = []
    executors = []
    admin_views = []
    menu_links = []